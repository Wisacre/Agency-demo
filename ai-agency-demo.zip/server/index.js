import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { spawn } from 'child_process';

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(bodyParser.json());

app.post('/api/generate', async (req, res) => {
  const { prompt, type } = req.body;

  if (!prompt || !type) {
    return res.status(400).json({ response: 'Missing prompt or type.' });
  }

  const ollama = spawn('ollama', ['run', 'mistral'], {
    stdio: ['pipe', 'pipe', 'pipe'],
  });

  let output = '';

  ollama.stdout.on('data', (data) => {
    output += data.toString();
  });

  ollama.stderr.on('data', (err) => {
    console.error(`stderr: ${err}`);
  });

  ollama.on('close', () => {
    res.json({ response: output.trim() });
  });

  ollama.stdin.write(`${prompt}\n`);
  ollama.stdin.end();
});

app.listen(PORT, () => {
  console.log(`✅ AI backend running at http://localhost:${PORT}`);
});
