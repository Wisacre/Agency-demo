# AI Agency Demo

This project showcases an automated AI agency demo with a frontend (React) and backend (Node.js + Ollama).

## Getting Started

### Frontend
```bash
cd frontend
npm install
npm run dev
```

### Backend
```bash
cd server
npm install express cors body-parser
node index.js
```

### Environment Variables
Create a `.env` file in `/frontend` with:
```
NEXT_PUBLIC_API_URL=http://localhost:3001
NEXT_PUBLIC_CALENDLY_URL=https://calendly.com/your-agency-booking
```

Make sure Ollama is installed and the `mistral` model is pulled.
```bash
ollama run mistral
```
